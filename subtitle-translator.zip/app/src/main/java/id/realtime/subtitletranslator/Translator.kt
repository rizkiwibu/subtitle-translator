package id.realtime.subtitletranslator

import android.util.Log
import org.json.JSONArray
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

object Translator {
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()

    fun translate(
        text: String,
        sourceLang: String,
        targetLang: String = "id",
        onResult: (String) -> Unit
    ) {
        val cleanText = text.trim()
        if (cleanText.isBlank()) return

        executor.execute {
            var translated = cleanText
            try {
                translated = request(cleanText, sourceLang, targetLang)
            } catch (t: Throwable) {
                Log.w("SubtitleTranslator", "Translation failed", t)
            }
            onResult(translated)
        }
    }

    private fun request(text: String, sourceLang: String, targetLang: String): String {
        val query = URLEncoder.encode(text, "UTF-8")
        val urlText = "https://translate.googleapis.com/translate_a/single" +
            "?client=gtx&sl=$sourceLang&tl=$targetLang&dt=t&q=$query"

        val connection = URL(urlText).openConnection() as HttpURLConnection
        connection.connectTimeout = 6_000
        connection.readTimeout = 6_000
        connection.requestMethod = "GET"
        connection.setRequestProperty("User-Agent", "Mozilla/5.0")

        val reader = BufferedReader(InputStreamReader(connection.inputStream))
        val response = StringBuilder()
        var line: String? = reader.readLine()
        while (line != null) {
            response.append(line)
            line = reader.readLine()
        }
        reader.close()

        val root = JSONArray(response.toString())
        val chunks = root.optJSONArray(0) ?: return text
        val builder = StringBuilder()
        for (i in 0 until chunks.length()) {
            val item = chunks.optJSONArray(i)
            val part = item?.optString(0).orEmpty()
            if (part.isNotBlank()) builder.append(part)
        }
        return builder.toString().trim().ifBlank { text }
    }
}
