package id.realtime.subtitletranslator

import android.graphics.Bitmap
import android.util.Log
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

object OcrHelper {
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    fun recognize(bitmap: Bitmap, sourceLang: String, onResult: (String) -> Unit) {
        if (bitmap.isRecycled || bitmap.width == 0 || bitmap.height == 0) return

        val image = InputImage.fromBitmap(bitmap, 0)
        recognizer.process(image)
            .addOnSuccessListener { text ->
                onResult(normalize(text.text))
            }
            .addOnFailureListener { error ->
                Log.w("SubtitleTranslator", "OCR failed: ${error.message}")
            }
    }

    private fun normalize(raw: String): String {
        return raw
            .replace("\n", " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }
}
