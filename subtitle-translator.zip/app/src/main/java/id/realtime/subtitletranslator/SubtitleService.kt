package id.realtime.subtitletranslator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.MediaProjection
import android.media.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class SubtitleService : Service() {
    private var mediaProjection: MediaProjection? = null
    private var imageReader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var handlerThread: HandlerThread? = null
    private var overlayText: TextView? = null
    private var windowManager: WindowManager? = null
    private var running = false

    private var lastOcrAtMs = 0L
    private var lastRawText = ""
    private var sourceLang = "auto"

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStopped() {
            stopAll()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopAll()
            return START_NOT_STICKY
        }

        if (running) return START_STICKY

        sourceLang = intent?.getStringExtra(EXTRA_SOURCE) ?: "auto"
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra<Intent>(EXTRA_DATA)
        }

        if (data == null) {
            stopAll()
            return START_NOT_STICKY
        }

        startForegroundWithNotification()
        showOverlay()
        setupCapture(resultCode, data)
        running = true
        return START_STICKY
    }

    override fun onDestroy() {
        stopAll()
        super.onDestroy()
    }

    private fun startForegroundWithNotification() {
        val channelId = "subtitle_translator"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(
                    channelId,
                    "Subtitle Translator",
                    NotificationManager.IMPORTANCE_LOW
                )
            )
        }

        val notification = Notification.Builder(this, channelId)
            .setContentTitle("Subtitle Translator")
            .setContentText("Membaca subtitle yang terlihat di layar...")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun showOverlay() {
        if (!Settings.canDrawOverlays(this)) return

        val textView = TextView(this).apply {
            text = ""
            textSize = 20f
            setTextColor(Color.WHITE)
            setBackgroundColor(0xAA000000.toInt())
            setPadding(24, 16, 24, 16)
            gravity = Gravity.CENTER
            visibility = android.view.View.GONE
        }

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = 120
        }

        try {
            windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            windowManager?.addView(textView, params)
            overlayText = textView
        } catch (_: Exception) {
            overlayText = null
        }
    }

    private fun setSubtitle(text: String) {
        Handler(Looper.getMainLooper()).post {
            val view = overlayText ?: return@post
            view.text = text
            view.visibility = if (text.isBlank()) android.view.View.GONE else android.view.View.VISIBLE
        }
    }

    private fun setupCapture(resultCode: Int, data: Intent) {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        handlerThread = HandlerThread("subtitle-capture").apply { start() }
        val handler = Handler(handlerThread!!.looper)

        mediaProjection = manager.getMediaProjection(resultCode, data).also { projection ->
            projection.registerCallback(projectionCallback, handler)
        }

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2).also { reader ->
            reader.setListener({ image -> onImageAvailable(image, width, height) }, handler)
        }

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "SubtitleCapture",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            handler
        )
    }

    private fun onImageAvailable(image: Image, width: Int, height: Int) {
        try {
            val now = SystemClock.elapsedRealtime()
            if (now - lastOcrAtMs < 900L) return
            lastOcrAtMs = now

            val bitmap = imageToBitmap(image, width, height)
            val subtitleArea = cropSubtitleArea(bitmap)
            bitmap.recycle()
            if (subtitleArea == null) return

            OcrHelper.recognize(subtitleArea, sourceLang) { rawText ->
                subtitleArea.recycle()
                if (rawText.isBlank() || rawText == lastRawText) return@recognize
                lastRawText = rawText
                Translator.translate(rawText, sourceLang) { translated ->
                    setSubtitle(translated)
                }
            }
        } finally {
            image.close()
        }
    }

    private fun imageToBitmap(image: Image, width: Int, height: Int): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        buffer.rewind()

        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        val bytes = ByteArray(rowStride * height)
        val remaining = buffer.remaining()
        buffer.get(bytes, 0, minOf(bytes.size, remaining))

        val pixels = IntArray(width * height)
        for (y in 0 until height) {
            for (x in 0 until width) {
                val offset = y * rowStride + x * pixelStride
                if (offset + 3 >= bytes.size) continue
                val r = bytes[offset].toInt() and 0xFF
                val g = bytes[offset + 1].toInt() and 0xFF
                val b = bytes[offset + 2].toInt() and 0xFF
                val a = bytes[offset + 3].toInt() and 0xFF
                pixels[y * width + x] = Color.argb(a, r, g, b)
            }
        }
        return Bitmap.createBitmap(pixels, width, height, Bitmap.Config.ARGB_8888)
    }

    private fun cropSubtitleArea(bitmap: Bitmap): Bitmap? {
        if (bitmap.width == 0 || bitmap.height == 0) return null
        val top = (bitmap.height * 0.58).toInt()
        val crop = Bitmap.createBitmap(bitmap, 0, top, bitmap.width, bitmap.height - top)
        val targetWidth = minOf(bitmap.width, 1280)
        val scale = targetWidth.toFloat() / bitmap.width.toFloat()
        val targetHeight = maxOf(1, (crop.height * scale).toInt())
        return if (targetWidth != bitmap.width) {
            val scaled = Bitmap.createScaledBitmap(crop, targetWidth, targetHeight, true)
            crop.recycle()
            scaled
        } else {
            crop
        }
    }

    private fun stopAll() {
        try {
            virtualDisplay?.release()
        } catch (_: Exception) {}
        try {
            imageReader?.close()
        } catch (_: Exception) {}
        try {
            mediaProjection?.unregisterCallback(projectionCallback)
        } catch (_: Exception) {}
        try {
            mediaProjection?.stop()
        } catch (_: Exception) {}

        virtualDisplay = null
        imageReader = null
        mediaProjection = null

        handlerThread?.quitSafely()
        handlerThread = null

        try {
            overlayText?.let { windowManager?.removeView(it) }
        } catch (_: Exception) {}
        overlayText = null
        windowManager = null

        running = false
        stopForeground(true)
        stopSelf()
    }

    companion object {
        private const val NOTIFICATION_ID = 1001
        private const val ACTION_STOP = "id.realtime.subtitletranslator.STOP"
        private const val EXTRA_RESULT_CODE = "result_code"
        private const val EXTRA_DATA = "data"
        private const val EXTRA_SOURCE = "source"

        fun start(context: Context, resultCode: Int, data: Intent, source: String) {
            val intent = Intent(context, SubtitleService::class.java).apply {
                putExtra(EXTRA_RESULT_CODE, resultCode)
                putExtra(EXTRA_DATA, data)
                putExtra(EXTRA_SOURCE, source)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, SubtitleService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }
}
