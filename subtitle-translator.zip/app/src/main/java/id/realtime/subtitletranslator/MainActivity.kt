package id.realtime.subtitletranslator

import android.app.MediaProjectionManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var spinnerSource: Spinner
    private lateinit var tvStatus: TextView

    private val sourceLabels = arrayOf("Otomatis", "Jepang", "Inggris")
    private val sourceCodes = arrayOf("auto", "ja", "en")

    private val captureLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val data = result.data
        if (result.resultCode == RESULT_OK && data != null) {
            val source = sourceCodes[spinnerSource.selectedItemPosition]
            setStatus("Capture layar berjalan. Buka video/game sekarang.")
            SubtitleService.start(this, result.resultCode, data, source)
        } else {
            setStatus("Izin capture layar ditolak.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        spinnerSource = findViewById(R.id.spinnerSource)
        tvStatus = findViewById(R.id.tvStatus)

        spinnerSource.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            sourceLabels
        )

        findViewById<Button>(R.id.btnOverlayPermission).setOnClickListener {
            if (Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Izin overlay sudah aktif.", Toast.LENGTH_SHORT).show()
            } else {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            }
        }

        findViewById<Button>(R.id.btnStart).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Aktifkan izin overlay dulu.", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            val manager = getSystemService(MediaProjectionManager::class.java)
            if (manager == null) {
                Toast.makeText(this, "MediaProjection tidak tersedia di HP ini.", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            setStatus("Menunggu izin capture layar...")
            captureLauncher.launch(manager.createScreenCaptureIntent())
        }

        findViewById<Button>(R.id.btnStop).setOnClickListener {
            SubtitleService.stop(this)
            setStatus("Dihentikan.")
        }
    }

    private fun setStatus(text: String) {
        tvStatus.text = text
    }
}
