# Subtitle Translator Real-Time

Aplikasi Android MVP untuk membaca subtitle **yang terlihat di layar**, lalu menerjemahkannya ke Bahasa Indonesia dan menampilkannya sebagai overlay.

## Cara kerja

1. User memberi izin **tampil di atas aplikasi lain**.
2. User memberi izin **capture layar**.
3. `SubtitleService` mengambil frame layar lewat `MediaProjection`.
4. Area bawah layar dipotong karena biasanya subtitle ada di sana.
5. Teks dibaca dengan **ML Kit OCR**.
6. Teks diterjemahkan ke Bahasa Indonesia.
7. Hasil terjemahan ditampilkan lewat overlay.

> Catatan penting: aplikasi ini tidak membaca data subtitle internal dari YouTube/game/app lain. Yang dibaca hanya teks yang terlihat secara visual di layar lewat OCR.

## Cara menjalankan

1. Buka folder ini di Android Studio.
2. Sinkronkan Gradle.
3. Jalankan ke HP Android (API 24+).
4. Aktifkan izin overlay di aplikasi.
5. Tekan **Mulai capture layar**, lalu setujui dialog capture layar Android.
6. Buka video/game yang ada subtitle JP/EN-nya.

## Batasan yang masih perlu diuji

- OCR bisa gagal kalau teks kecil, transparan, atau banyak animasi.
- Video DRM/protected mungkin tidak bisa ditangkap.
- Capture layar harus selalu ada notifikasi foreground service.
- Kecepatan real-time tergantung HP dan internet.

## File utama

- `MainActivity.kt` — UI dan izin.
- `SubtitleService.kt` — capture layar, crop area subtitle, OCR, terjemahan, overlay.
- `OcrHelper.kt` — ML Kit OCR.
- `Translator.kt` — HTTP translator ke Bahasa Indonesia.
